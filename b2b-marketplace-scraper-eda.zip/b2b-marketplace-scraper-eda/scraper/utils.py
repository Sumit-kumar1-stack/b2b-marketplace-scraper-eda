import os
import csv
import json

OUTPUT_DIR = "output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def save_data(data):
    if not data:
        print("❌ No data to save")
        return
    
    csv_path = os.path.join(OUTPUT_DIR, "suppliers.csv")
    json_path = os.path.join(OUTPUT_DIR, "suppliers.json")
    
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

    print(f"\n✅ Data saved to {csv_path} and {json_path}")
