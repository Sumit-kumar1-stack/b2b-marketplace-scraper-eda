from playwright.sync_api import sync_playwright
import time
import random
from .utils import save_data

CATEGORIES = {
    "Industrial Machinery": "industrial machinery",
    "Electrical Equipment": "electrical equipment",
}

BASE_URL = "https://www.alibaba.com/trade/search?SearchText={query}"

def scrape_all():
    all_data = []

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=["--disable-blink-features=AutomationControlled"]
        )
        context = browser.new_context()
        page = context.new_page()

        for category, query in CATEGORIES.items():
            print(f"\nFetching category: {category}")

            url = BASE_URL.format(query=query.replace(" ", "+"))
            page.goto(url, timeout=60000)
            page.wait_for_timeout(7000)

            # Scroll to load content
            for _ in range(4):
                page.mouse.wheel(0, 4000)
                page.wait_for_timeout(2000)

            # Grab all visible text blocks that look like product titles
            product_links = page.locator("a[href*='/product-detail/']")

            count = product_links.count()
            print(f"Found {count} product links")

            for i in range(min(count, 15)):
                text = product_links.nth(i).inner_text().strip()

                if not text or len(text) < 10:
                    continue

                all_data.append({
                    "category": category,
                    "supplier_name": "N/A",
                    "location": "N/A",
                    "products": text
                })

            time.sleep(random.uniform(2, 4))

        browser.close()

    if not all_data:
        print("⚠️ No data scraped, skipping save")
        return []

    save_data(all_data)
    return all_data
