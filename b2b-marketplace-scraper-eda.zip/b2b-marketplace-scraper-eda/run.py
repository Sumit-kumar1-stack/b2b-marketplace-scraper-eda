from scraper import alibaba_scraper
from eda import eda_analysis
from utils.mock_data import save_mock_data
import os

if __name__ == "__main__":
    print("🚀 Starting Alibaba B2B Scraper")
    scraped = alibaba_scraper.scrape_all()

    if not scraped or not os.path.exists("output/suppliers.csv"):
        print("⚠️ Scraping blocked. Generating mock data instead.")
        save_mock_data()

    print("\n📊 Running EDA Analysis")
    eda_analysis.run_eda()
