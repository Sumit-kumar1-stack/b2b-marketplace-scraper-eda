import os
import csv
import random

OUTPUT_DIR = "output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

SUPPLIERS = [
    "Shenzhen Industrial Co., Ltd",
    "Guangzhou Machinery Works",
    "Zhejiang Electric Systems",
    "Jiangsu Automation Ltd",
    "Dongguan Heavy Industries",
    "Shanghai Mechanical Corp",
    "Ningbo Power Equipment",
    "Foshan Industrial Solutions",
]

COUNTRIES = [
    "China", "India", "Germany", "USA",
    "South Korea", "Japan", "Vietnam"
]

PRODUCTS = [
    "CNC Machine",
    "Industrial Motor",
    "Power Transformer",
    "Hydraulic Pump",
    "Control Panel",
    "Electric Switchgear",
]

CATEGORIES = [
    "Industrial Machinery",
    "Electrical Equipment"
]


def generate_mock_data(n=50):
    rows = []
    for _ in range(n):
        rows.append({
            "category": random.choice(CATEGORIES),
            "supplier_name": random.choice(SUPPLIERS),
            "location": random.choice(COUNTRIES),
            "products": random.choice(PRODUCTS),
        })
    return rows


def save_mock_data():
    data = generate_mock_data()
    csv_path = os.path.join(OUTPUT_DIR, "suppliers.csv")

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["category", "supplier_name", "location", "products"]
        )
        writer.writeheader()
        writer.writerows(data)

    print(f"✅ Mock data generated at: {csv_path}")
