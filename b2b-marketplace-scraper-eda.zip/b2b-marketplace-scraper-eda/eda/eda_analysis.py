import pandas as pd
import matplotlib.pyplot as plt
import os

OUTPUT_DIR = "output"
EDA_DIR = os.path.join(OUTPUT_DIR, "eda")
os.makedirs(EDA_DIR, exist_ok=True)


def run_eda():
    csv_path = os.path.join(OUTPUT_DIR, "suppliers.csv")

    if not os.path.exists(csv_path):
        print("⚠️ suppliers.csv not found. Skipping EDA.")
        return

    df = pd.read_csv(csv_path)

    print("\n=== Dataset Info ===")
    print(df.info())

    print("\n=== First 5 Rows ===")
    print(df.head())

    print("\n=== Summary Statistics ===")
    print(df.describe(include="all"))

    # Top suppliers
    print("\n=== Top 10 Suppliers ===")
    top_suppliers = df["supplier_name"].value_counts().head(10)
    print(top_suppliers)

    plt.figure()
    top_suppliers.plot(kind="bar")
    plt.title("Top 10 Suppliers")
    plt.tight_layout()
    plt.savefig(os.path.join(EDA_DIR, "top_suppliers.png"))
    plt.close()

    # Locations
    if df["location"].notna().any():
        print("\n=== Top 10 Countries ===")
        top_countries = df["location"].value_counts().head(10)
        print(top_countries)

        plt.figure()
        top_countries.plot(kind="bar")
        plt.title("Top Supplier Countries")
        plt.tight_layout()
        plt.savefig(os.path.join(EDA_DIR, "top_countries.png"))
        plt.close()
    else:
        print("⚠️ No valid location data to plot")

    # Products
    print("\n=== Top 10 Products ===")
    top_products = df["products"].value_counts().head(10)
    print(top_products)

    plt.figure()
    top_products.plot(kind="bar")
    plt.title("Top Products")
    plt.tight_layout()
    plt.savefig(os.path.join(EDA_DIR, "top_products.png"))
    plt.close()

    # Category distribution
    print("\n=== Category Distribution ===")
    category_counts = df["category"].value_counts()
    print(category_counts)

    plt.figure()
    category_counts.plot(kind="bar")
    plt.title("Category Distribution")
    plt.tight_layout()
    plt.savefig(os.path.join(EDA_DIR, "category_distribution.png"))
    plt.close()

    print("\n✅ EDA completed successfully")
    print(f"📁 Plots saved in: {EDA_DIR}")
